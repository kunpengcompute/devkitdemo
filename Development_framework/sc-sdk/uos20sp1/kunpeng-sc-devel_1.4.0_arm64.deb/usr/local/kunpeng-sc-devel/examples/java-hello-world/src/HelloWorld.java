public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Running HelloWorld.class in the TEE.");
        System.out.println("Hello World!");
        System.out.println("The programe is about to exit.");
    }
}
