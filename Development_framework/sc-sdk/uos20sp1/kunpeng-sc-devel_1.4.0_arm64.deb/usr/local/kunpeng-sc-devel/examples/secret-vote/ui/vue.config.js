module.exports = {
    publicPath: '/static',
    outputDir: 'dist'
}